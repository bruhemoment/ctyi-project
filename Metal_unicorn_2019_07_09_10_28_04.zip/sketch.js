let score = 0;
let a =0;
let x, y;

function getClickPosition(e) {
                var xPosition = e.clientX;
                var yPosition = e.clientY;
                score++;
        }

function setup() {
  createCanvas(400, 400);
 x1 = 200
  y1 = 100

  x2 = 315
    y2 = 100

  x3 = 225
  y3 = 160
  xy3 = 192
  radius = 65
  

  
}
function draw() {
  background(200);

  stroke(50);
  fill(38,0,77);
  rect(x1,y1,250,50);
  
  fill(85,225,51)
  rect(x2,y2,25,50);
  
  
    stroke(50)
  fill(255,128,128);
  triangle(xy3,y3,y3,x3,x3,x3 );
  
  x1 = x1 - 1;
  x2 = x2 - 1;

  if (x1 < -125) {
    x1 = width;
  }
  
  
  if (x2 < -125) {
    x2 = width;
  }
  
  
  function mousePressed() {
      let d = dist(mouseX, mouseY, x3, y3);
            if (d<triangle){
              score++;
            }
  }
      
text("Score: " + score, 10, 20);
    
}

document.addEventListener("click", getClickPosition, false);
